java -cp ~/UClarkson/grants/TUES2012/mango:commons-httpclient-3.0.1.jar:commons-logging.jar:commons-codec-1.3.jar HttpRetriever
